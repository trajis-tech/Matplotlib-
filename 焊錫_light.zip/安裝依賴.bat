@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "PY_EXE=%CD%\portable_python\python.exe"
set "REQ=%CD%\requirements.txt"
set "GETPIP=%CD%\portable_python\get-pip.py"
set "CURL=%SystemRoot%\System32\curl.exe"
set "CERTUTIL=%SystemRoot%\System32\certutil.exe"

if not exist "%PY_EXE%" (
    echo ERROR: 找不到 portable_python\python.exe
    echo 請把 portable Python 放在此資料夾下。
    pause
    exit /b 1
)

if not exist "%REQ%" (
    echo ERROR: 找不到 requirements.txt
    pause
    exit /b 1
)

echo Using: %PY_EXE%
echo.

"%PY_EXE%" -m pip --version >nul 2>nul
if errorlevel 1 (
    echo pip 尚未安裝，正在下載 get-pip.py ...
    if exist "%CURL%" (
        "%CURL%" -L --fail --silent --show-error -o "%GETPIP%" https://bootstrap.pypa.io/get-pip.py
    ) else (
        "%CERTUTIL%" -urlcache -split -f https://bootstrap.pypa.io/get-pip.py "%GETPIP%" >nul
    )
    if errorlevel 1 goto :dlfail
    if not exist "%GETPIP%" goto :dlfail

    echo 正在安裝 pip ...
    "%PY_EXE%" "%GETPIP%" --no-warn-script-location
    set "PIPERR=%ERRORLEVEL%"
    del /q "%GETPIP%" >nul 2>nul
    if not "%PIPERR%"=="0" (
        echo ERROR: pip 安裝失敗，代碼 %PIPERR%。
        pause
        exit /b %PIPERR%
    )
)

echo 正在安裝 / 更新依賴 ...
"%PY_EXE%" -m pip install --upgrade --disable-pip-version-check --no-warn-script-location -r "%REQ%"
if errorlevel 1 (
    echo ERROR: 依賴安裝失敗。
    pause
    exit /b 1
)

echo.
echo 安裝完成，版本如下：
"%PY_EXE%" -c "import numpy,cv2,PIL; print('numpy', numpy.__version__); print('cv2', cv2.__version__); print('PIL', PIL.__version__)"
if errorlevel 1 (
    echo ERROR: 套件已安裝但無法 import。
    pause
    exit /b 1
)

echo.
pause
exit /b 0

:dlfail
echo ERROR: 無法下載 get-pip.py，請確認網路連線。
if exist "%GETPIP%" del /q "%GETPIP%" >nul 2>nul
pause
exit /b 1
